# -*- coding: utf-8 -*-
import os
import sys

from source.experiments.experiment_pipline import DenseNetPipline
from source.experiments.holter_pipline import HolterPipline

sys.path.append(os.path.dirname(os.path.abspath(__file__)))


class DenseNetHolter(HolterPipline, DenseNetPipline):
    # don't need to implement anything
    pass


def main():
    pipline = DenseNetHolter()
    config, datamodule, model, trainer = pipline.train()
    config, datamodule, model, trainer = pipline.validate(config, datamodule, model)


if __name__ == "__main__":
    main()
