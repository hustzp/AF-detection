# -*- coding: utf-8 -*-
import h5py
import numpy as np


def remove_noise(sequence, seg_len):
    """
    For Holter data we have noise label -1. Remove those segments with noise.
    For AFDB data this function just simply reshape the array.

    :param sequence: shape of [length, ... + label]
    :param seg_len:
    :return: sub_seq [batch, seg len, channel]
    """
    # Traverse the noise index
    noise_index = np.where(sequence[:, -1] == -1)[0]
    sub_seq = []
    start = 0
    for end in noise_index:
        if end - start >= seg_len:
            # Intercept the part between the two noises
            seq = sequence[start:end]
            seq = np.reshape(seq[:seq.shape[0] // seg_len * seg_len], (-1, seg_len, seq.shape[1]))
            sub_seq.append(seq)
        start = end + 1
    # Process the end of the segment
    if sequence.shape[0] - start >= seg_len:
        seq = sequence[start:]
        seq = np.reshape(seq[:seq.shape[0] // seg_len * seg_len], (-1, seg_len, seq.shape[1]))
        sub_seq.append(seq)
    # sub_seq [batch, seg len, channel]
    sub_seq = np.concatenate(sub_seq, 0)
    return sub_seq


def load_hdf(hdf_file_path, in_place=False):
    """
    try to load rri array in hdf file

    :param hdf_file_path:
    :return: file, rri: [seq len, time + rri + label]
    """
    try:
        file = h5py.File(hdf_file_path, 'r')
    except:
        return None, None
    try:
        if in_place:
            rri = file['rri'][:]
            file.close()
            return rri[:]
        else:
            return file, file['rri']
    except:
        return file, None
