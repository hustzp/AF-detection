# -*- coding: utf-8 -*-
import os
import pickle
import sys
import tempfile
import warnings

sys.path.append(os.path.dirname(os.path.abspath(__file__)))


def get_stem(path_str):
    """
    same effect to pathlib.Path.stem
    """
    return os.path.splitext(os.path.basename(path_str))[0]


def try_save_pkl(obj, file_path):
    try:
        os.makedirs(os.path.dirname(file_path), exist_ok=True)
        with open(file_path, 'wb') as file:
            pickle.dump(obj, file)
            print(f"{file_path} saved")
        return file_path
    except PermissionError:
        tmp_dir = tempfile.gettempdir()
        save_dir = os.path.join(tmp_dir, os.path.basename(os.path.dirname(file_path)))
        os.makedirs(save_dir, exist_ok=True)
        save_path = os.path.join(save_dir, os.path.basename(file_path))
        warnings.warn(f"permission denied, try to save file in temp dir: {save_path}")
        try:
            with open(save_path, 'wb') as file:
                pickle.dump(obj, file)
                print(f"{save_path} saved")
            return save_path
        except:
            raise

