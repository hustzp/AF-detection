# -*- coding: utf-8 -*-
import glob
import os.path
from itertools import repeat
from typing import Sequence

import h5py

from source.utils.mp import async_run
from source.data.holter.rr_file import RRFile
from source.utils.path_tools import get_stem


def create_hdf(hdf_save_dir, data_file: RRFile):
    """

    :param hdf_save_dir:
    :param data_file_path:
    :return:
    """
    name = get_stem(data_file.file_path)
    file_save_path = os.path.join(hdf_save_dir, name + '.h5')
    if not os.path.exists(file_save_path):
        try:
            data_file.extract()
        except:
            print(f"fail to build hdf for {data_file.file_path}")
            return
        rri = data_file.data_array
        file = h5py.File(file_save_path, 'w')
        file.create_dataset('rri', data=rri, chunks=True)
        file.close()


def build_hdf_files(save_dir, files: Sequence[RRFile]):
    os.makedirs(save_dir, exist_ok=True)
    async_run(create_hdf, zip(repeat(save_dir), files), desc='build hdf files')
    print("hdf files build complete")

