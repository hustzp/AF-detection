# -*- coding: utf-8 -*-
import multiprocessing as mp
import pandas as pd
import numpy as np
import os
import re
from tqdm import tqdm

from source.data.segments_builder import _preprocess_rr


class RRFile:
    def __init__(
            self,
            file_path=None,
            extract_header=True
    ):
        """

        :param file_path: the txt/hrv file path for holter data
        :param extract_header: set to False for some NAF file with no "End header" line
        """
        self.extract_header = extract_header
        self.file_path = file_path
        self.file_data = None
        self.time = None
        self.start_time = None
        self.label = None
        self.seq = None
        self.seq_label = None
        self.data_array = None
        self.data_df = None
        self.aux_note = None

    def extract(self):
        assert os.path.exists(self.file_path)

        self.label = []

        with open(self.file_path, encoding='gbk') as f:
            self.file_data = f.readlines()

        self.start_time = self._get_start_time() if self.extract_header else 0
        if self.extract_header:
            self._get_label()
        self._data_process()

        try:
            self.data_array = np.vstack((self.time, self.seq, self.seq_label)).T.astype(float)
        except:
            print(self.file_path)
        self.data_df = pd.DataFrame.from_records(self.data_array, columns=['time', 'rr_interval', 'label'])

        return self.seq, self.seq_label

    def _get_start_time(self):
        for index, line in enumerate(self.file_data):
            if line.startswith('Start time'):
                line = line.split(':')
                return int(line[1]) * 3600 + int(line[2]) * 60

    def _get_label(self):
        i = 4
        while self.file_data[i][:2] != 'RR' and self.file_data[i] != '\n':
            cur = self.file_data[i].strip()
            if cur[-1] == '0' or cur[-1] == ')':
                time1 = int(cur[:2]) * 3600 + int(cur[3:5]) * 60 + int(cur[6:8])
                second = int(cur.split('(')[-1].split(')')[0])
                if time1 < self.start_time:
                    time1 += 24 * 3600
                self.label.append([time1, time1 + second])
            i += 1

    def _data_process(self):
        i = 0
        for line in self.file_data:
            i += 1
            if line.strip() == 'End header':
                break
        if self.extract_header:
            # extract time second
            self.time = np.asarray(
                [int(line[1:3]) * 3600 + int(line[4:6]) * 60 + int(line[7:9]) for line in self.file_data[i:]])
            # for the next day time
            if np.any(self.time < self.start_time):
                tomorrow_first_index = np.argmax(self.time < self.start_time)
                self.time[tomorrow_first_index:] += 24 * 3600
            # extract RR intervals
            self.seq = np.asarray([re.findall(r"[A-Z](\d+)", line)[0]
                                   if len(re.findall(r"[A-Z](\d+)", line)) > 0 else 0 for line in
                                   self.file_data[i:]], dtype=int)
            self.seq_label = np.zeros_like(self.seq)
            for each in self.label:
                self.seq_label[(self.time >= each[0]) & (self.time <= each[1])] = 1
            # extract labels
            self.aux_note = np.asarray([re.findall(r"[A-Z]", line)[0]
                                        if len(re.findall(r"[A-Z]", line)) > 0 else 'Z' for line in
                                        self.file_data[i:]])
        else:
            if i < len(self.file_data):
                file_data = self.file_data[i:]
            else:
                file_data = self.file_data
            self.time = np.arange(len(file_data))
            self.seq = np.asarray([line.strip().split(' ')[0][1:] for line in file_data], dtype=np.int64)
            self.seq_label = np.zeros_like(self.seq)
            self.aux_note = np.asarray([line.strip().split(' ')[0][0] for line in file_data])

        # noise
        self.seq_label[self.aux_note == 'Z'] = -1
        self.seq_label[(self.seq < 200) | (self.seq > 2000)] = -1
