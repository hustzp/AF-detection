# -*- coding: utf-8 -*-
import os
import sys
from itertools import repeat

import numpy as np
import pandas as pd

from source.utils.data_tools import load_hdf, remove_noise
from source.utils.mp import async_run
from source.utils.path_tools import get_stem

sys.path.append(os.path.dirname(os.path.abspath(__file__)))


def _seg_info(data, file_name, interval):
    """

    :param data:  [num seg, index + time + n channels + label, interval]
    :param file_name:
    :param interval:
    :return:
    """
    seg_info = pd.DataFrame({
        'name': file_name,
        'index': data[:, 0, 0].astype(int),
        'seg_len': data.shape[-1],
        'start_time': data[:, 1].min(1),
        'interval': interval,
        'type': np.nan
    })
    # make sure we do not have noise
    assert not np.any(data[:, -1] == -1)
    seg_type = data[:, -1].sum(1)
    # NAF segment
    seg_info.loc[(seg_type >= 0) & (seg_type < data.shape[-1] // 2), 'type'] = 'NAF'
    # AF segment
    seg_info.loc[(seg_type >= data.shape[-1] // 2) & (seg_type <= data.shape[-1]), 'type'] = 'AF'
    return seg_info


def _preprocess_rr(rri, interval):
    rri = remove_noise(rri, interval).transpose((0, 2, 1))  # [batch, channel, seg len]
    return rri


def _get_rri_seg_info(file_name, rri, interval):
    rri = np.concatenate([np.arange(rri.shape[0]).reshape(-1, 1), rri], 1)  # rri: [seq len, index + time + rri + label]
    rri = _preprocess_rr(rri, interval)  # rri: [num seg, index + time + rri + label, interval]
    seg_info = _seg_info(rri, file_name, interval)
    seg_info.sort_values('start_time', inplace=True, ignore_index=True)
    return seg_info


def _create_seg_info(hdf_file_path, interval):
    file_name = get_stem(hdf_file_path)
    file, rri = load_hdf(hdf_file_path)  # rri: [seq len, time + rri + label]
    if file is None:
        print(f'fail to load file {file_name}')
        return pd.DataFrame()
    try:
        if rri is not None:
            rri_seg_info = _get_rri_seg_info(file_name, rri, interval)
        else:
            rri_seg_info = pd.DataFrame()
    except:
        print(f'fail to build segment information for {file_name}')
        file.close()
        return pd.DataFrame()
    file.close()
    return rri_seg_info


def build_segment_info(hdf_file_paths, segments_save_path, interval=30):
    rri_seg_info_list = async_run(_create_seg_info, zip(hdf_file_paths, repeat(interval)), desc=f'build segment info for {interval} interval')
    rri_seg_info_list = pd.concat(rri_seg_info_list, ignore_index=True)
    os.makedirs(os.path.dirname(segments_save_path), exist_ok=True)
    rri_seg_info_list.to_hdf(segments_save_path, f"rri_{interval}interval", format='fixed')
    print("segment files build complete")
