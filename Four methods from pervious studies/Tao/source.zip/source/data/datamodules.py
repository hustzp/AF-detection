# -*- coding: utf-8 -*-
import os
import pickle
import sys
import tempfile
from pathlib import Path

import torch.utils.data as td
import torch
import pytorch_lightning as pl

from source.data.segments_sampler import SegmentSampler
from source.utils.data_tools import load_hdf
from source.utils.mp import async_run
from source.utils.path_tools import get_stem, try_save_pkl

sys.path.append(os.path.dirname(os.path.abspath(__file__)))


class Segments(td.Dataset):
    def __init__(self, hdf_files, segment_data, all_data=None):
        """
        dataset for segments

        :param hdf_files: hdf file list
        :param segment_data: dataframe of segments
        """
        self.hdf_files = {get_stem(file): file for file in hdf_files}
        self.segment_data = segment_data
        self.all_data = all_data

    def __len__(self):
        return len(self.segment_data)

    def __getitem__(self, index):
        seg_info = self.segment_data.iloc[index]
        file, rri = self.load_hdf(seg_info['name'])  # rri: [length, time+rri+label]
        return self._get_seg(rri, seg_info, file)

    def load_hdf(self, name):
        if self.all_data is None:
            return load_hdf(self.hdf_files[name])
        else:
            return None, self.all_data[name]

    def _get_seg(self, seq, seg_info, file=None):
        # Get the fragment and the corresponding tag
        start = seg_info['index']
        end = seg_info['index'] + seg_info['seg_len']
        seg = seq[start:end].T  # seg: [time+n channels+label, seg len]
        time, data, labels = seg[0], seg[1:-1], seg[-1]
        # to tensor
        time = torch.tensor(time, dtype=torch.float)
        data = torch.tensor(data, dtype=torch.float)
        labels = torch.tensor(labels, dtype=torch.float)  # labels for segmentation
        # label for classification
        if seg_info['type'] == 'NAF':
            seg_type = torch.tensor(0, dtype=torch.float)
        elif seg_info['type'] == 'AF':
            seg_type = torch.tensor(1, dtype=torch.float)
        else:
            raise ValueError("segment type error, please check the segment file")
        if file is not None:
            file.close()
        return time, data, labels, seg_type, seg_info.to_dict()


class SegmentsDataModule(pl.LightningDataModule):
    def __init__(
            self,
            hdf_files,
            folds,
            train_sampler: SegmentSampler = None,
            val_sampler: SegmentSampler = None,
            batch_size=128,
            num_workers=12,
            lazy_load=False,
    ):
        super(SegmentsDataModule, self).__init__()
        self.hdf_files = hdf_files
        self.train_sampler = train_sampler
        self.val_sampler = val_sampler
        self.batch_size = batch_size
        self.num_workers = num_workers

        self.folds = folds
        self.fold_id = 0
        self.set_fold_use(0)

        self.train_ds = None
        self.val_ds = None
        self.all_data = None
        if not lazy_load:
            self.all_data = self.load_all_data()

    @staticmethod
    def _load(x):
        return get_stem(x), load_hdf(x, True)

    def load_all_data(self):
        # find data root dir first
        file_path = Path(self.hdf_files[0])
        p = file_path.parent
        last_p = p
        while not 'data' in p.name:
            last_p = p
            p = p.parent
        file_path = os.path.join(tempfile.gettempdir(), last_p.name)
        os.makedirs(file_path, exist_ok=True)
        file_path = os.path.join(file_path, 'all_data.pkl')
        # load all data
        if not os.path.exists(file_path):
            all_data = async_run(self._load, self.hdf_files, lambda x: (x,), "loading all data")
            all_data = {x[0]: x[1] for x in all_data}
            # save to pkl file
            try_save_pkl(all_data, file_path)
        else:
            with open(file_path, 'rb') as file:
                all_data = pickle.load(file)
            print(f"loaded all data from {str(file_path)}")
        return all_data

    def set_fold_use(self, n):
        self.fold_id = n
        print(f"using fold {n} with {len(self.current_fold[0])} training files, {len(self.current_fold[1])} validation files")

    @property
    def current_fold(self):
        return self.folds[self.fold_id]

    @property
    def train_file_names(self):
        return self._get_names(self.current_fold[0])

    @property
    def val_file_names(self):
        return self._get_names(self.current_fold[1])

    @staticmethod
    def _get_names(files_list):
        return [get_stem(file) for file in files_list]

    def setup(self, stage=None):
        if self.train_sampler is not None:
            train_seg_info = self.train_sampler.sample(self.train_file_names)
            self.train_ds = Segments(self.hdf_files, train_seg_info, self.all_data)
            print(f"train seg info:\n{train_seg_info['type'].value_counts()}")
        if self.val_sampler is not None:
            val_seg_info = self.val_sampler.sample(self.val_file_names)
            self.val_ds = Segments(self.hdf_files, val_seg_info, self.all_data)
            print(f"val seg info:\n{val_seg_info['type'].value_counts()}")

    def train_dataloader(self):
        print(f"train_dataloader function call: using fold {self.fold_id}")
        return td.DataLoader(self.train_ds, self.batch_size, shuffle=True, pin_memory=True, num_workers=self.num_workers, persistent_workers=True)

    def val_dataloader(self):
        print(f"val_dataloader function call: using fold {self.fold_id}")
        # keep 'shuffle=True' to avoid zero metric value in some batch
        return td.DataLoader(self.val_ds, self.batch_size, shuffle=True, pin_memory=True, num_workers=self.num_workers, persistent_workers=True)


class TestDataModule(SegmentsDataModule):
    def __init__(
            self,
            hdf_files,
            test_sampler,
            batch_size=128,
            num_workers=12,
            lazy_load: bool = False):
        folds = [[[], hdf_files]]
        super().__init__(
            hdf_files=hdf_files,
            folds=folds,
            val_sampler=test_sampler,
            batch_size=batch_size,
            num_workers=num_workers,
            lazy_load=lazy_load
        )

    def set_fold_use(self, n):
        # n is ignored since we only have the test files
        self.fold_id = 0
        print(f"loaded {len(self.current_fold[1])} test files")
