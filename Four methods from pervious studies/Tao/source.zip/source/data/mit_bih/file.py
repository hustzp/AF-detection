# -*- coding: utf-8 -*-
import os
import sys

sys.path.append(os.path.dirname(os.path.abspath(__file__)))
import wfdb as w
import wfdb.processing as wp
from abc import abstractmethod, ABC
import numpy as np
import pandas as pd

BEAT_ANNOTATIONS = list("NLRBAaJSVrFejnE/fQ?")


class MitBihFile(ABC):
    def __init__(self, record_name, ecg_sample_rate=128):
        self.record_name = record_name
        self.ecg_sample_rate = ecg_sample_rate
        self.annotation = w.rdann(self.record_name, 'atr')

    def get_ecg_data(self):
        """

        :param record_name:
        :param target_sample_rate:
        :return: ecg data [length, time + 2 channels + label]
        """
        record, info = w.rdsamp(self.record_name)
        record, annotation = wp.resample_multichan(record, self.annotation, self.annotation.fs, self.ecg_sample_rate)
        label = np.zeros(record.shape[0])
        start = 0
        af_begin = False
        for idx, label_name in zip(annotation.sample, annotation.aux_note):
            if "AFIB" in label_name:
                if not af_begin:
                    start = idx
                    af_begin = True
            else:
                if af_begin:
                    label[start:idx] = 1
                    af_begin = False
        # process the end of the segment
        if af_begin:
            label[start:] = 1
        time = np.arange(record.shape[0]) / annotation.fs
        data = np.c_[time, record, label]
        return data

    @abstractmethod
    def get_r_peak_position(self):
        raise NotImplementedError

    def get_rri_data(self):
        """
        :return: rri data [length, time + rr interval + label]
        """
        r_peak_position = self.get_r_peak_position()
        label = np.zeros_like(r_peak_position, float)
        start = 0
        af_begin = False
        for idx, label_name in zip(self.annotation.sample, self.annotation.aux_note):
            if "AFIB" in label_name:
                if not af_begin:
                    start = idx
                    af_begin = True
            else:
                if af_begin:
                    label[(r_peak_position >= start) & (r_peak_position <= idx)] = 1.
                    af_begin = False
        # process the end of the segment
        if af_begin:
            label[r_peak_position >= start] = 1
        rri = np.diff(r_peak_position) / self.annotation.fs * 1000
        label = label[:-1]
        time = r_peak_position[:-1] / self.annotation.fs
        data = np.c_[time, rri, label]
        return data


class AFDB(MitBihFile):
    def get_r_peak_position(self):
        if os.path.exists(self.record_name + '.qrsc'):
            qrs = w.rdann(self.record_name, 'qrsc')
        elif os.path.exists(self.record_name + '.qrs'):
            qrs = w.rdann(self.record_name, 'qrs')
        else:
            raise FileNotFoundError
        return qrs.sample


class MITDB(MitBihFile):
    def get_r_peak_position(self):
        df = pd.DataFrame({"sample": self.annotation.sample, "symbol": self.annotation.symbol})
        r_peak_position = df.loc[df['symbol'].isin(BEAT_ANNOTATIONS), "sample"].to_numpy()
        return r_peak_position


def main():
    import glob
    fp = glob.glob("/home/uu201913134/ECG202207/Data/mit-bih/mit-bih-atrial-fibrillation-database-1.0.0/files/08405.dat")
    mitdb = AFDB(os.path.splitext(fp[0])[0])
    print(mitdb.get_r_peak_position())
    ecg_data = mitdb.get_ecg_data()
    rri_data = mitdb.get_rri_data()
    print(rri_data)
    print(np.any(rri_data[:, 2] == 1))
    print(pd.Series(rri_data[:, -1]).value_counts())
    print(pd.Series(ecg_data[:, -1]).value_counts())


if __name__ == "__main__":
    main()
