# -*- coding: utf-8 -*-
import glob
import os.path
from itertools import repeat

import h5py
import pandas as pd
from typing import Sequence

from source.data.mit_bih.file import MitBihFile, AFDB
from source.utils.mp import async_run


def create_hdf(hdf_save_dir, mit_bih_file: MitBihFile):
    """

    :param hdf_save_dir:
    :param mit_bih_file:
    :return:
    """
    name = os.path.basename(mit_bih_file.record_name)
    file_save_path = os.path.join(hdf_save_dir, name + '.h5')
    # ecg = mit_bih_file.get_ecg_data()
    rri = mit_bih_file.get_rri_data()
    file = h5py.File(file_save_path, 'w')
    # file.create_dataset('ecg', data=ecg, chunks=True)
    file.create_dataset('rri', data=rri, chunks=True)
    file.close()


def build_hdf_files(save_dir, files: Sequence[MitBihFile]):
    os.makedirs(save_dir, exist_ok=True)
    async_run(create_hdf, zip(repeat(save_dir), files), desc='build hdf files')
    print("hdf files build complete")


def create_csv(save_dir, mit_bih_file: MitBihFile):
    rri = mit_bih_file.get_rri_data()
    df = pd.DataFrame(rri, columns=['time', 'rri', 'label'])
    name = os.path.basename(mit_bih_file.record_name)
    file_save_path = os.path.join(save_dir, name + '.csv')
    df.to_csv(file_save_path, index=False)


def build_csv_files(save_dir, files: Sequence[MitBihFile]):
    os.makedirs(save_dir, exist_ok=True)
    async_run(create_csv, zip(repeat(save_dir), files), desc='build csv files')
    print("csv files build complete")


def main():
    file_list = [AFDB(os.path.splitext(f)[0], 250) for f in glob.iglob(r"D:\@work\Projects\AF_detection_RR\data\mit-bih-atrial-fibrillation-database-1.0.0\files\*.dat")]
    build_hdf_files(r"D:\@work\Projects\AF_detection_RR\data\mit-bih-atrial-fibrillation-database-1.0.0\afdb_hdf", file_list)


if __name__ == "__main__":
    main()
