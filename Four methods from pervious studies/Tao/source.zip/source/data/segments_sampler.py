# -*- coding: utf-8 -*-
import os
import sys

import pandas as pd

sys.path.append(os.path.dirname(os.path.abspath(__file__)))


class SegmentSampler:
    def __init__(
            self,
            segment_file_path,
    ):
        self.segment_file_path = segment_file_path
        self.segment_data = None

    def read_segment_data(self, interval):
        print("read segment data...")
        self.segment_data = pd.read_hdf(self.segment_file_path, f"rri_{interval}interval")
        print(f"loaded segment data for {interval} interval, shape: {self.segment_data.shape}")

    def get_patient_seg(self, names):
        # filter by name
        return self.segment_data.loc[self.segment_data['name'].isin(names)]

    def sample(self, names):
        return self.get_patient_seg(names)
