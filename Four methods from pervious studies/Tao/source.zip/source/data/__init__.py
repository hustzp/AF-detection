# -*- coding: utf-8 -*-

"""
@author: Fang SiYi
@software: PyCharm
@file: __init__.py
@time: 2022-09-04 10:56
"""
import os
import sys

sys.path.append(os.path.dirname(os.path.abspath(__file__)))
