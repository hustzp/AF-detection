# -*- coding: utf-8 -*-
import os
import random
import sys

from source.utils.array_tools import make_folds
from source.utils.path_tools import get_stem

sys.path.append(os.path.dirname(os.path.abspath(__file__)))


def make_folds_inter_patients(file_list: list, k_folds=10, num_test_patients=3):
    file_list = file_list.copy()
    random.shuffle(file_list)
    file_cv, file_test = file_list[num_test_patients:], file_list[:num_test_patients]
    folds = make_folds(file_cv, k_folds)
    return folds, file_cv, file_test

