# -*- coding: utf-8 -*-
import os
import pickle
import sys
from typing import Any, Optional

import matplotlib.pyplot as plt
import pandas as pd
import pytorch_lightning as pl
import torch
from pytorch_lightning.callbacks import TQDMProgressBar
from pytorch_lightning.utilities.rank_zero import rank_zero_only
from pytorch_lightning.utilities.types import STEP_OUTPUT
from tqdm import tqdm
import numpy as np
from source.utils.array_tools import to_scalar, tensor_to_array
from source.utils.path_tools import try_save_pkl

sys.path.append(os.path.dirname(os.path.abspath(__file__)))


def cal_subplot_layout(num_plots, base_size=5):
    """
    Calculate the best number of rows and columns of the graph from the total number of subplots, and figure size
    """
    row = np.sqrt(num_plots).astype(int)
    col = np.ceil(num_plots / row).astype(int)
    figsize = base_size * np.asarray([col, row])
    return row, col, figsize


class MetricsTool(pl.Callback):
    def __init__(self, metrics_func_dict, log_dir=None, fold_id=0):
        self.fold_id = fold_id
        self.log_dir = log_dir
        self.metrics_func_dict = metrics_func_dict
        self.train_step_y = []
        self.train_epoch_metrics = []
        self.val_step_y = []
        self.val_epoch_metrics = []

    def calculate_metrics(self, y_pred, y_true, name_prefix=''):
        """

        :param y_pred:
        :param y_true:
        :param name_prefix:
        :return: Returns a dictionary containing the metrics name and its value
        """
        return {
            f"{name_prefix}{metrics_name}": to_scalar(metrics_func(y_pred, y_true))
            for metrics_name, metrics_func in self.metrics_func_dict.items()
        }

    @rank_zero_only
    def plot_metrics(self, title=None):
        train_metrics_df = pd.DataFrame.from_records(self.train_epoch_metrics)
        val_metrics_df = pd.DataFrame.from_records(self.val_epoch_metrics)
        metrics_df = pd.concat([train_metrics_df, val_metrics_df], axis=1)
        plt.figure()
        metrics_df.plot(ax=plt.gca())
        plt.title(title)
        if self.log_dir is not None:
            plt.savefig(os.path.join(self.log_dir, f"metrics_fold{self.fold_id}.png"))
        plt.show()

    @rank_zero_only
    def plot_metrics_subplots(self, title=None):
        train_metrics_df = pd.DataFrame.from_records(self.train_epoch_metrics)
        val_metrics_df = pd.DataFrame.from_records(self.val_epoch_metrics)
        metrics_df = pd.concat([train_metrics_df, val_metrics_df], axis=1)
        row, col, figsize = cal_subplot_layout(len(self.metrics_func_dict), 5)
        plt.figure(figsize=figsize)
        plt.suptitle(title)
        for i, name in enumerate(self.metrics_func_dict.keys()):
            plt.subplot(row, col, i + 1)
            plt.title(name)
            plt.xlabel("epoch")
            plt.ylabel("value")
            metrics_df[[name, f"val_{name}"]].plot(ax=plt.gca())
            plt.legend()
        plt.tight_layout()
        if self.log_dir is not None:
            plt.savefig(os.path.join(self.log_dir, f"metrics_subplots_fold{self.fold_id}.png"))
        plt.show()

    def on_train_batch_end(
            self,
            trainer: "pl.Trainer",
            pl_module: "pl.LightningModule",
            outputs: STEP_OUTPUT,
            batch: Any,
            batch_idx: int
    ) -> None:
        self.train_step_y.append(outputs['y'])

        m = self.calculate_metrics(*outputs['y'], name_prefix='')
        pl_module.log_dict(m, prog_bar=True, sync_dist=True)

    def on_validation_batch_end(
            self,
            trainer: "pl.Trainer",
            pl_module: "pl.LightningModule",
            outputs: Optional[STEP_OUTPUT],
            batch: Any,
            batch_idx: int,
            dataloader_idx: int = 0,
    ) -> None:
        self.val_step_y.append(outputs['y'])

    def on_validation_epoch_end(self, trainer: "pl.Trainer", pl_module: "pl.LightningModule") -> None:
        # train metrics
        if len(self.train_step_y) > 0:
            y_pred, y_true = list(zip(*self.train_step_y))
            y_pred = torch.cat(y_pred, 0)
            y_true = torch.cat(y_true, 0)
            m = self.calculate_metrics(y_pred, y_true, '')
            self.train_epoch_metrics.append(m)
            self.print_metrics(m)
            self.train_step_y = []

        # val metrics
        y_pred, y_true = list(zip(*self.val_step_y))
        y_pred = torch.cat(y_pred, 0)
        y_true = torch.cat(y_true, 0)
        m = self.calculate_metrics(y_pred, y_true, 'val_')
        self.val_epoch_metrics.append(m)
        self.print_metrics(m)
        self.val_step_y = []

        pl_module.log_dict(m, prog_bar=True, sync_dist=True)
        if trainer.current_epoch > 0:
            self.plot_metrics(f"epoch {trainer.current_epoch + 1}")
            self.plot_metrics_subplots(f"epoch {trainer.current_epoch + 1}")

    @rank_zero_only
    def print_metrics(self, metrics_dict: dict):
        print("\nmetrics:")
        for k, v in metrics_dict.items():
            print(f"{k}:{v:.5f}")

    def state_dict(self):
        return {
            "train_epoch_metrics": self.train_epoch_metrics,
            "val_epoch_metrics": self.val_epoch_metrics,
        }

    def load_state_dict(self, state_dict) -> None:
        self.train_epoch_metrics = state_dict['train_epoch_metrics']
        self.val_epoch_metrics = state_dict['val_epoch_metrics']


class PredictionRecorder(pl.Callback):
    def __init__(self, log_file_path):
        self.log_file_path = log_file_path
        self.step_y = []
        self.step_info = []

    def on_validation_batch_end(
            self,
            trainer: "pl.Trainer",
            pl_module: "pl.LightningModule",
            outputs: Optional[STEP_OUTPUT],
            batch: Any,
            batch_idx: int,
            dataloader_idx: int = 0,
    ) -> None:
        self.step_y.append([t.numpy() for t in outputs['y']])
        self.step_info.append({k: tensor_to_array(v) for k, v in outputs['seg_info'].items()})

    def on_validation_epoch_end(self, trainer: "pl.Trainer", pl_module: "pl.LightningModule") -> None:
        epoch_preds = list(zip(self.step_y, self.step_info))
        try_save_pkl(epoch_preds, self.log_file_path)
        self.step_y = []
        self.step_info = []


class LitProgressBar(TQDMProgressBar):
    """This class disable validation tqdm to avoid glitch of validation progress bar in PyCharm"""

    def init_train_tqdm(self) -> tqdm:
        """ Override this to customize the tqdm bar for training. """
        bar = tqdm(
            desc='Training',
            position=(2 * self.process_position),
            disable=self.is_disabled,
            leave=True,
            dynamic_ncols=False,  # This two lines are only for pycharm
            ncols=100,
            file=sys.stdout,
            smoothing=0,
        )
        return bar

    def init_validation_tqdm(self) -> tqdm:
        """ Override this to customize the tqdm bar for validation. """
        bar = tqdm(
            disable=True
        )
        return bar

    def init_test_tqdm(self) -> tqdm:
        """ Override this to customize the tqdm bar for testing. """
        bar = tqdm(
            desc="Testing",
            position=(2 * self.process_position),
            disable=self.is_disabled,
            leave=True,
            dynamic_ncols=False,
            ncols=100,
            file=sys.stdout
        )
        return bar
