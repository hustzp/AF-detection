# -*- coding: utf-8 -*-
import os
import sys
from typing import List, Any

import torch
import torch.nn.functional as F
from pytorch_lightning.utilities.types import STEP_OUTPUT
from torch import nn

from source.trainer.base import TaskBase

sys.path.append(os.path.dirname(os.path.abspath(__file__)))


class ClassifierTrainer(TaskBase):
    def general_step(self, batch, batch_idx) -> STEP_OUTPUT:
        time, data, labels, seg_type, seg_info = batch
        logits = self.model(data)
        loss = F.cross_entropy(logits, seg_type.long())
        y_pred = logits.softmax(1)[:, 1]
        return {
            'loss': loss,
            'y': (y_pred.detach().cpu(), seg_type.detach().cpu()),
            'seg_info': seg_info
        }


class MultiModelsClassifier(TaskBase):
    def __init__(self, model_list: List[nn.Module]):
        model_list = nn.ModuleList(model_list)
        super().__init__(model_list)

    def forward(self, *args, **kwargs) -> Any:
        return [model(*args, **kwargs) for model in self.model]

    def general_step(self, batch, batch_idx) -> STEP_OUTPUT:
        time, data, labels, seg_type, seg_info = batch
        logits = torch.stack(self(data))
        y_pred = logits.softmax(2).mean(0)[:, 1]
        return {
            'y': (y_pred.detach().cpu(), seg_type.detach().cpu()),
            'seg_info': seg_info
        }

    def training_step(self, batch, batch_idx) -> STEP_OUTPUT:
        # This class is for validation/test only
        raise NotImplementedError
