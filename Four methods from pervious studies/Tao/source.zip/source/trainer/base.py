# -*- coding: utf-8 -*-
import os
import sys
from typing import Optional, Any

import pytorch_lightning as pl
import torch
from pytorch_lightning.utilities.types import STEP_OUTPUT

sys.path.append(os.path.dirname(os.path.abspath(__file__)))


class TaskBase(pl.LightningModule):
    def __init__(
            self,
            model
    ):
        super().__init__()
        self.automatic_optimization = False
        self.model = model

    def forward(self, *args, **kwargs) -> Any:
        return self.model(*args, **kwargs)

    def general_step(self, batch, batch_idx) -> STEP_OUTPUT:
        raise NotImplementedError

    def training_step(self, batch, batch_idx) -> STEP_OUTPUT:
        step_output = self.general_step(batch, batch_idx)
        opt = self.optimizers()
        opt.zero_grad()
        self.manual_backward(step_output['loss'])
        opt.step()
        return step_output

    def validation_step(self, batch, batch_idx) -> Optional[STEP_OUTPUT]:
        return self.general_step(batch, batch_idx)

    def test_step(self, batch, batch_idx) -> Optional[STEP_OUTPUT]:
        return self.general_step(batch, batch_idx)

    def configure_optimizers(self):
        return torch.optim.Adam(self.model.parameters(), lr=1e-3)
