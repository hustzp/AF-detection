# -*- coding: utf-8 -*-
from datetime import datetime
import os
import sys
import argparse
from pathlib import Path
from typing import Literal

import torch.nn
import torchmetrics as tm

sys.path.append(os.path.dirname(os.path.abspath(__file__)))


def get_project_dir():
    file_path = Path(os.path.abspath(__file__))
    return str(file_path.parent.parent.parent)


class ExperimentConfig:
    def __init__(self):
        # basic path
        self.project_dir = get_project_dir()
        self.raw_data_dir = os.path.join(self.project_dir, "data/mit-bih-atrial-fibrillation-database-1.0.0/files/")
        self.hdf_data_dir = os.path.join(self.project_dir, "data/mit-bih-atrial-fibrillation-database-1.0.0/afdb_hdf")
        self.data_file_pattern = '*.h5'
        self.segment_file_path = os.path.join(self.hdf_data_dir, "segments.hdf")
        self.fold_file_path = os.path.join(self.hdf_data_dir, "folds.pkl")

        # log path
        self.log_dir = os.path.join(self.project_dir, f'logs/{datetime.now().strftime("%Y%m%d")}_DenseNet_AFDB')
        self.log_file_path = os.path.join(self.log_dir, "val_results_fold{fold_id}.pkl")

        # data
        self.intervals = 30
        self.k_folds = 10
        self.batch_size = 128
        self.split_mode = 'inter'  # intra/inter
        self.lazy_load = False  # Whether to enable real-time data reading to save memory consumption at run time. If True, the data is read in real time using h5py
        # intra-patients
        self.train_ratio = 0.8
        self.val_ratio = 0
        # inter-patients
        self.start_fold = 0
        self.single_fold = True  # train "start_fold" only
        self.num_test_patients = 3

        # model
        self.input_channels = 1
        self.num_classes = 2
        self.model_checkpoint = None
        self.model_checkpoint_pattern = "model*.ckpt"

        # train
        self.devices = "auto"
        self.max_epochs = 10
        self.precision = 32
        self.num_workers = min(os.cpu_count(), 32)
        self.stage: Literal["cross validate", "test"] = "cross validate"

    @property
    def metrics_func_dict(self):
        return {
            'ce': torch.nn.BCELoss(),
            'auroc': tm.AUROC('binary'),
            'accuracy': tm.Accuracy('binary'),
            'sensitive': tm.Recall('binary'),
            'specificity': tm.Specificity('binary'),
        }

    def parse_args(self, args=None):
        ap = argparse.ArgumentParser()
        # TODO: make variables in argparse
        # ap.add_argument()
        ap.parse_args(args, namespace=self)
