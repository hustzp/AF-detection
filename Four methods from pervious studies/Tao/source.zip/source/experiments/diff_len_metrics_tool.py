# -*- coding: utf-8 -*-
import multiprocessing as mp
import os
import sys
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn import metrics
from tqdm import tqdm

from source.experiments.result_processor import read_result_hdf
from source.utils.math_tools import confidence_interval_bootstrap

sys.path.append(os.path.dirname(os.path.abspath(__file__)))


class PAFSegMetrics:
    """
    evaluate result for AF with different duration
    """

    def __init__(self, hdf_save_dir, result_save_dir):
        self.hdf_save_dir = Path(hdf_save_dir)
        self.result_save_dir = Path(result_save_dir)

    def get_all_seg_metrics(self):
        pool = mp.Pool()
        pred_files = self.result_save_dir.glob("*_result.h5")
        result_getter = [pool.apply_async(self.get_file_seg_metrics, (f,)) for f in pred_files]
        pool.close()
        result = []
        with tqdm(result_getter) as t:
            for rg in t:
                res = rg.get()
                if len(res) > 0:
                    df = pd.DataFrame(res)
                    t.set_postfix_str(f"accuracy: {df['accuracy'].mean()}")
                    result.extend(res)
        pool.join()
        return result

    def get_file_seg_metrics(self, file):
        data_file = self.hdf_save_dir / f"{file.stem.split('_result')[0]}.h5"
        try:
            comp = read_result_hdf(file, data_file)
        except:
            return []

        # find label==1, exclude pred==-1
        seg_info_list = []
        diff_label = np.diff(comp[:, 1])
        diff_index = np.where(diff_label != 0)[0]
        start = 0
        for i in diff_index:
            if np.all(comp[start:i + 1, 1] == 1) and np.all(comp[start:i + 1, 2] != -1):
                seg_info = self._make_seg_info(data_file.stem, comp, start, i + 1)
                # print(seg_info)
                seg_info_list.append(seg_info)
            start = i + 1
        # last seg
        if np.all(comp[start:, 1] == 1) and np.all(comp[start:, 2] != -1):
            seg_info = self._make_seg_info(data_file.stem, comp, start, comp.shape[0])
            seg_info_list.append(seg_info)
        return seg_info_list

    @staticmethod
    def _make_seg_info(name, seg, start, end):
        return {
            'name': name,
            'start': start,
            'end': end,
            'duration': seg[end - 1, 0] - seg[start, 0],
            'accuracy': metrics.accuracy_score(seg[start:end, 1].astype(int), seg[start:end, 2].round().astype(int)),
        }


def get_overall_diff_len_metrics(hdf_save_dir, result_save_dir, df):
    print(f"get diff len metrics for {df['name'].unique()}")
    segments = [[], [], []]
    result_data_dict = {}
    for index, row in df.iterrows():
        pred_file = os.path.join(result_save_dir, f"{row['name']}_result.h5")
        data_file = os.path.join(hdf_save_dir, f"{row['name']}.h5")
        if not row['name'] in result_data_dict.keys():
            y_comp = read_result_hdf(pred_file, data_file)  # [len, time+label+pred label]
            result_data_dict[row['name']] = y_comp
        else:
            y_comp = result_data_dict[row['name']]
        if row['duration'] < 30:
            segments[0].append(y_comp[row['start']:row['end'], 1:])
        elif row['duration'] >= 30 and row['duration'] <= 60:
            segments[1].append(y_comp[row['start']:row['end'], 1:])
        elif row['duration'] >= 60:
            segments[2].append(y_comp[row['start']:row['end'], 1:])

    def get_acc_ci(x):
        x = np.concatenate(x)
        acc = metrics.accuracy_score(x[:, 0].astype(int), x[:, 1].round().astype(int))
        lower, higher = confidence_interval_bootstrap(x[:, 1].round().astype(int), x[:, 0].astype(int), 1000, 0.95, metrics.accuracy_score)
        return acc, lower, higher

    df = pd.DataFrame(index=["below30s", "30to60s", "over60s"], columns=['accuracy', 'acc_lower', 'acc_higher'])
    for i, s in enumerate(segments):
        if len(s) > 0:
            df.iloc[i, :] = get_acc_ci(s)
        else:
            df.iloc[i, :] = np.nan
    return df


def get_average_diff_len_metrics(df):
    a1 = df.loc[df['duration'] < 30, 'accuracy'].mean()
    print("<30s AF accuracy:{}".format(a1))
    a2 = df.loc[(df['duration'] >= 30) & (df['duration'] <= 60), 'accuracy'].mean()
    print("30s~60s AF accuracy:{}".format(a2))
    a3 = df.loc[df['duration'] > 60, 'accuracy'].mean()
    print(">60s AF accuracy:{}".format(a3))
