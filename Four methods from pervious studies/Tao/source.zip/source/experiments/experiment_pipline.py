# -*- coding: utf-8 -*-
import glob
import os
import pickle
import sys
from abc import abstractmethod, ABC

import pandas as pd
import pytorch_lightning as pl
import torch.cuda
from lightning_fabric.accelerators import find_usable_cuda_devices
from torchinfo import summary

from source.data.datamodules import SegmentsDataModule, TestDataModule
from source.data.segments_sampler import SegmentSampler
from source.experiments.config import ExperimentConfig
from source.model.densenet_blstm import DenseNet_BLSTM
from source.trainer.callbacks import MetricsTool, LitProgressBar, PredictionRecorder
from source.trainer.classifier_trainer import ClassifierTrainer, MultiModelsClassifier
from source.utils.path_tools import try_save_pkl

sys.path.append(os.path.dirname(os.path.abspath(__file__)))


class ExperimentPipline(ABC):
    def configure_hyperparams(self):
        config = ExperimentConfig()
        config.parse_args()
        os.makedirs(config.log_dir, exist_ok=True)
        print(vars(config))
        return config

    @abstractmethod
    def prepare_data(self, config=None):
        raise NotImplementedError

    def configure_datamodule(self, config=None):
        if config.split_mode == "inter":
            sampler = SegmentSampler(config.segment_file_path)
            sampler.read_segment_data(config.intervals)
            with open(config.fold_file_path, 'rb') as f:
                folds, file_cv, file_test = pickle.load(f)
            if config.stage == "cross validate":
                datamodule = SegmentsDataModule(
                    hdf_files=file_cv,
                    folds=folds,
                    train_sampler=sampler,
                    val_sampler=sampler,
                    batch_size=config.batch_size,
                    num_workers=config.num_workers,
                    lazy_load=config.lazy_load,
                )
            elif config.stage == "test":
                datamodule = TestDataModule(
                    hdf_files=file_test,
                    test_sampler=sampler,
                    batch_size=config.batch_size,
                    num_workers=config.num_workers,
                    lazy_load=config.lazy_load,
                )
            else:
                raise ValueError
        elif config.split_mode == "intra":
            # todo: implement intra patient fold maker
            raise NotImplementedError
        else:
            raise ValueError(f"config.split_mode should be intra or inter, got {config.split_mode} instead")
        return datamodule

    @abstractmethod
    def configure_model(self, config=None):
        raise NotImplementedError

    def train(self, config=None, datamodule=None, model=None, trainer=None):
        if config is None:
            config = self.configure_hyperparams()
        if datamodule is None:
            datamodule = self.configure_datamodule(config)
        if model is None:
            model = self.configure_model(config)
        if trainer is None:
            trainer = pl.Trainer(
                enable_checkpointing=True,
                logger=False,
                accelerator='gpu' if torch.cuda.is_available() else 'cpu',
                strategy="ddp_find_unused_parameters_False" if isinstance(config.devices, int) and config.devices > 1 else "auto",  # "ddp_find_unused_parameters_False",
                devices=find_usable_cuda_devices(config.devices) if isinstance(config.devices, int) else config.devices,
                max_epochs=config.max_epochs,
                precision=config.precision,
                num_sanity_val_steps=0,
                callbacks=[
                    MetricsTool(config.metrics_func_dict, config.log_dir, datamodule.fold_id),
                    LitProgressBar(),
                    pl.callbacks.ModelCheckpoint(
                        dirpath=config.log_dir,
                        filename=f"model_fold{datamodule.fold_id}" + "_{epoch}_{val_auroc:.4f}_{val_accuracy:.4f}_{val_sensitive:.4f}_{val_specificity:.4f}",
                        monitor='val_auroc',
                        mode='max',
                        save_last=True,
                    ),
                ]
            )
        trainer.fit(model, datamodule=datamodule)
        return config, datamodule, model, trainer

    def validate(self, config=None, datamodule=None, model=None, trainer=None):
        if config is None:
            config = self.configure_hyperparams()
        if datamodule is None:
            datamodule = self.configure_datamodule(config)
        if model is None:
            model = self.configure_model(config)
        if trainer is None:
            trainer = pl.Trainer(
                enable_checkpointing=False,
                logger=False,
                accelerator='gpu' if torch.cuda.is_available() else 'cpu',
                devices=find_usable_cuda_devices(1) if torch.cuda.is_available() else 'auto',
                precision=config.precision,
                num_sanity_val_steps=0,
                callbacks=[
                    MetricsTool(config.metrics_func_dict),
                    PredictionRecorder(config.log_file_path.format(fold_id=datamodule.fold_id)),
                ]
            )
        trainer.validate(model, datamodule=datamodule)
        return config, datamodule, model, trainer

    def predict(self, config=None, datamodule=None, model=None, trainer=None):
        pass


class AFDB_Pipline(ExperimentPipline, ABC):
    def prepare_data(self, config=None):
        # check hdf files
        hdf_files = glob.glob(os.path.join(config.hdf_data_dir, config.data_file_pattern))
        if not len(hdf_files) == 23:
            print("hdf files not found, trying to build from raw data")
            from source.data.mit_bih.file import AFDB
            file_list = [AFDB(os.path.splitext(f)[0], 250) for f in glob.iglob(os.path.join(config.raw_data_dir, "*.dat"))]
            if len(file_list) < 23:
                raise FileNotFoundError
            from source.data.mit_bih.preprocess import build_hdf_files
            build_hdf_files(config.hdf_data_dir, file_list)
        hdf_files = glob.glob(os.path.join(config.hdf_data_dir, config.data_file_pattern))
        # check segment file
        if not os.path.exists(config.segment_file_path):
            from source.data.segments_builder import build_segment_info
            build_segment_info(hdf_files, config.segment_file_path, config.intervals)
        else:
            # check specific interval exists
            segment_data = pd.HDFStore(config.segment_file_path, 'r')
            if not f"/rri_{config.intervals}interval" in segment_data.keys():
                segment_data.close()
                from source.data.segments_builder import build_segment_info
                build_segment_info(hdf_files, config.segment_file_path, config.intervals)
            else:
                segment_data.close()
        # check fold file
        if not os.path.exists(config.fold_file_path):
            print("create folds")
            if config.split_mode == "inter":
                from source.data.folds_maker import make_folds_inter_patients
                folds, file_cv, file_test = make_folds_inter_patients(hdf_files, config.k_folds, config.num_test_patients)
                try_save_pkl((folds, file_cv, file_test), config.fold_file_path)
            elif config.split_mode == "intra":
                # todo: implement intra patient fold maker
                raise NotImplementedError
            else:
                raise ValueError(f"config.split_mode should be intra or inter, got {config.split_mode} instead")


class DenseNetPipline(ExperimentPipline, ABC):
    def configure_model(self, config=None):
        model = DenseNet_BLSTM(
            in_features=config.input_channels,
            growth_rate=32,
            block_config=(6, 6, 6, 6),
            bn_size=4,
            drop_rate=0,
            num_classes=config.num_classes
        )
        if config.model_checkpoint is not None:
            task = ClassifierTrainer.load_from_checkpoint(
                config.model_checkpoint,
                model=model,
            )
        else:
            task = ClassifierTrainer(
                model,
            )
        summary(task, (config.batch_size, config.input_channels, config.intervals), device='cpu')
        return task


class DenseNetMultiModelPipline(ExperimentPipline, ABC):
    def configure_model(self, config=None):
        model_paths = glob.glob(os.path.join(config.log_dir, config.model_checkpoint_pattern))
        model_list = []
        for model_checkpoint in model_paths:
            model = DenseNet_BLSTM(
                in_features=config.input_channels,
                growth_rate=32,
                block_config=(6, 6, 6, 6),
                bn_size=4,
                drop_rate=0,
                num_classes=config.num_classes
            )
            task = ClassifierTrainer.load_from_checkpoint(
                model_checkpoint,
                model=model,
            )
            model = task.model.to('cpu')
            model_list.append(model)
        task = MultiModelsClassifier(model_list)
        return task
