# -*- coding: utf-8 -*-
import os
import pickle
import sys
from itertools import repeat
from pathlib import Path
from typing import List

import h5py
import numpy as np
import pandas as pd

from source.utils.data_tools import load_hdf
from source.utils.mp import async_run

sys.path.append(os.path.dirname(os.path.abspath(__file__)))


class ValResultWriter:
    """
    Merge the tag of the test results recorded by the PredictionRecorder
     with the tag of the raw data into a new hdf file
    """

    @staticmethod
    def merge_label(hdf_save_dirs, result_save_dir, val_results: List):
        async_run(ValResultWriter._merge_label, zip(repeat(hdf_save_dirs), repeat(result_save_dir), val_results), desc="merge label")

    @staticmethod
    def _merge_label(hdf_save_dirs, result_save_dir, val_result):
        # the save path of the predict label
        result_save_dir = Path(result_save_dir)
        result_save_dir.mkdir(parents=True, exist_ok=True)
        step_y_pred = val_result[0][0]
        step_info = val_result[1]
        step_info = pd.DataFrame(step_info)
        # iterate batch
        for i, seg_y_pred in enumerate(step_y_pred):
            # search data hdf in all dirs
            if isinstance(hdf_save_dirs, List):
                for d in hdf_save_dirs:
                    data_hdf_file = os.path.join(d, f"{step_info.loc[i, 'name']}.h5")
                    if os.path.exists(data_hdf_file):
                        break
            else:
                data_hdf_file = os.path.join(hdf_save_dirs, f"{step_info.loc[i, 'name']}.h5")
            assert os.path.exists(data_hdf_file)

            # Loads the raw data to create a sequence of prediction tags of the same length
            while True:
                file, rri = load_hdf(data_hdf_file)
                if file is not None:
                    break
            # save predicted label to file
            ValResultWriter._append_result(
                result_save_dir / f"{step_info.loc[i, 'name']}_result.h5",
                rri.shape[0],
                step_info.loc[i, :],
                seg_y_pred,
            )
            file.close()

    @staticmethod
    def _append_result(result_save_path, data_length, seg_info, seg_y_pred):
        while True:
            try:
                file = h5py.File(result_save_path, 'a')
            except:
                file = None
            if file is not None:
                break
        if "rri_result" not in file.keys():
            file.create_dataset("rri_result", data=np.full(data_length, -1, dtype=np.float32), chunks=True)
        file["rri_result"][seg_info["index"]:seg_info["index"] + seg_info["seg_len"]] = seg_y_pred
        file.close()


def read_result_hdf(pred_file, data_file):
    """

    :param data_file:
    :param pred_file:
    :return: [len, time+label+pred label]
    """
    pred_hdf = h5py.File(pred_file, 'r')
    data_hdf = h5py.File(data_file, 'r')
    data = data_hdf['rri'][:, [0, -1]]  # data: [len, time+label]
    pred = pred_hdf['rri_result']  # pred: [len, pred label]
    comp = np.c_[data, pred]  # [len, time+label+pred label]
    return comp


def make_result_data_dict(data_path, result_path):
    data_path = Path(data_path)
    result_path = Path(result_path)
    result_data_dict = {}
    for result_file in result_path.glob('*_result.h5'):
        data_file_list = list(data_path.glob(f"{result_file.stem.split('_result')[0]}.h5"))
        if len(data_file_list) > 0:
            assert len(data_file_list) == 1
            data_file = data_file_list[0]
            result_data_dict[result_file] = data_file
    return result_data_dict


def read_results(result_file_list):
    val_results = []
    for file_path in result_file_list:
        with open(file_path, 'rb') as file:
            val_result = pickle.load(file)
        val_results.extend(val_result)
    return val_results
