# -*- coding: utf-8 -*-
import glob
import os
import pickle
import sys
from abc import ABC
from itertools import chain
from pathlib import Path

import pandas as pd

from source.data.holter.preprocess import build_hdf_files
from source.data.holter.rr_file import RRFile
from source.data.segments_builder import build_segment_info
from source.experiments.config import ExperimentConfig
from source.experiments.experiment_pipline import ExperimentPipline
from source.utils.path_tools import try_save_pkl

sys.path.append(os.path.dirname(os.path.abspath(__file__)))


class HolterPipline(ExperimentPipline, ABC):
    def find_annotation_files(self, config: ExperimentConfig):
        train_files = list(map(str, (Path(config.raw_data_dir) / "Train").rglob("*.*")))
        val_files = list(map(str, (Path(config.raw_data_dir) / "Val").rglob("*.*")))
        # test files
        test_files = []
        for fp in map(str, chain((Path(config.raw_data_dir) / "Test").rglob("*.txt"), (Path(config.raw_data_dir) / "Test").rglob("*.hrv"))):
            if not "公共数据集" in fp:
                test_files.append(fp)
        return train_files, val_files, test_files

    def build_hdf_files(self, config: ExperimentConfig):
        train_files, val_files, test_files = self.find_annotation_files(config)
        train_files = [RRFile(f, True) for f in train_files]
        build_hdf_files(os.path.join(config.hdf_data_dir, "Train"), train_files)
        val_files = [RRFile(f, True) for f in val_files]
        build_hdf_files(os.path.join(config.hdf_data_dir, "Val"), val_files)
        # test files
        test_rr_files = []
        for tf in test_files:
            if "_annotations" in tf:
                test_rr_files.append(RRFile(tf, True))
            else:
                test_rr_files.append(RRFile(tf, False))
        build_hdf_files(os.path.join(config.hdf_data_dir, "Test"), test_rr_files)

    def build_segment_info(self, config: ExperimentConfig):
        hdf_file_paths = list(map(str, Path(config.hdf_data_dir).rglob(config.data_file_pattern)))
        build_segment_info(hdf_file_paths, config.segment_file_path, config.intervals)

    def build_fold_file(self, config: ExperimentConfig):
        train_files = list(map(str, (Path(config.hdf_data_dir) / "Train").rglob(config.data_file_pattern)))
        val_files = list(map(str, (Path(config.hdf_data_dir) / "Val").rglob(config.data_file_pattern)))
        test_files = list(map(str, (Path(config.hdf_data_dir) / "Test").rglob(config.data_file_pattern)))
        print(len(train_files), len(val_files), len(test_files))
        file_cv = train_files + val_files
        # only have one fold
        folds = [[train_files, val_files]]
        try_save_pkl((folds, file_cv, test_files), config.fold_file_path)

    def prepare_data(self, config=None):
        self.build_hdf_files(config)
        self.build_segment_info(config)
        self.build_fold_file(config)
