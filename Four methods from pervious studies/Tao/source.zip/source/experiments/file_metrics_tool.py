# -*- coding: utf-8 -*-
import glob
import os

os.environ['CUDA_VISIBLE_DEVICES'] = ''
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import torch

torch.multiprocessing.set_start_method('spawn', force=True)
torch.multiprocessing.set_sharing_strategy('file_system')
import torchmetrics as tm
from torchmetrics import functional as tmf

from source.utils.math_tools import confidence_interval_bootstrap
from source.utils.mp import async_run
from source.experiments.result_processor import read_result_hdf, ValResultWriter, make_result_data_dict, read_results

sys.path.append(os.path.dirname(os.path.abspath(__file__)))


class FileMetrics:
    def __init__(self, result_data_dict):
        self.file_results = None
        self.result_data_dict = result_data_dict

    def _get_file_result(self, pred_file, data_file):
        while True:
            try:
                file_result = read_result_hdf(pred_file, data_file)
            except:
                file_result = None
            if file_result is not None:
                break
        return file_result

    def _get_y(self, y_combined, return_tensor=True):
        y_combined = y_combined[(y_combined[:, 1] != -1) & (y_combined[:, 2] != -1)]
        if return_tensor:
            y_true = torch.as_tensor(y_combined[:, 1], dtype=torch.int32)
            y_pred = torch.as_tensor(y_combined[:, 2], dtype=torch.float32)
        else:
            y_true = np.asarray(y_combined[:, 1], dtype=int)
            y_pred = np.asarray(y_combined[:, 2], dtype=float)
        return y_pred, y_true

    def concat_file_results(self):
        result = async_run(self._get_file_result, self.result_data_dict.items(), desc="concat file results")
        self.file_results = np.concatenate(result, 0)
        print(f"concat result shape: {self.file_results.shape}")
        return self.file_results

    def get_record_metrics(self, pred_file, data_file):
        """
        calculate metrics of single record

        :param data_file:
        :param pred_file:
        :return:
        """
        file_result = self._get_file_result(pred_file, data_file)
        y_pred, y_true = self._get_y(file_result)
        m = {
            'name': Path(data_file).stem,
            'auroc': tmf.auroc(y_pred, y_true, task='binary').numpy(),
            'accuracy': tmf.accuracy(y_pred, y_true, task='binary').numpy(),
            'sensitive': tmf.recall(y_pred, y_true, task='binary').numpy(),
            'specificity': tmf.specificity(y_pred, y_true, task='binary').numpy(),
        }
        return m

    def get_all_record_metrics(self):
        """
        calculate metrics of each record
        :return:
        """
        result = async_run(self.get_record_metrics, self.result_data_dict.items(), desc="get all record metrics")
        result = pd.DataFrame.from_records(result)
        return result

    def get_overall_metrics(self):
        """
        Aggregate the results of all records
        :return:
        """
        if self.file_results is None:
            self.concat_file_results()
        y_pred, y_true = self._get_y(self.file_results)
        m = {
            'auroc': tmf.auroc(y_pred, y_true, task='binary').item(),
            'accuracy': tmf.accuracy(y_pred, y_true, task='binary').item(),
            'sensitive': tmf.recall(y_pred, y_true, task='binary').item(),
            'specificity': tmf.specificity(y_pred, y_true, task='binary').item(),
        }
        metrics = pd.DataFrame(m, index=['value'])

        return metrics

    def get_overall_roc_curve(self, num_points=2000):
        if self.file_results is None:
            self.concat_file_results()
        y_pred, y_true = self._get_y(self.file_results)
        fpr, tpr, thresholds = tmf.roc(y_pred, y_true, task='binary')
        roc = {
            'fpr': fpr.tolist(),
            'tpr': tpr.tolist(),
            'thresholds': thresholds.tolist()
        }
        roc = pd.DataFrame(roc)
        if roc.shape[0] >= num_points:
            roc = roc.iloc[::roc.shape[0] // num_points]
            roc = pd.concat([roc.iloc[[0]], roc.iloc[1:].sample(num_points - 2).sort_index(), pd.DataFrame([[1, 1, 0]], columns=roc.columns)], axis=0, ignore_index=True)
        return roc

    def get_overall_confidence_interval(self):
        if self.file_results is None:
            self.concat_file_results()
        y_pred, y_true = self._get_y(self.file_results)
        base_metric_dict = {
            'auroc': tm.AUROC('binary'),
            'accuracy': tm.Accuracy('binary'),
            'sensitive': tm.Recall('binary'),
            'specificity': tm.Specificity('binary'),
        }
        confidence_interval_df = pd.DataFrame(index=['lower', 'higher'], columns=list(base_metric_dict.keys()))
        for metric_name, metric_func in base_metric_dict.items():
            lower, higher = confidence_interval_bootstrap(y_pred, y_true, 1000, 0.95, metric_func)
            confidence_interval_df.loc['lower', metric_name] = lower
            confidence_interval_df.loc['higher', metric_name] = higher
        return confidence_interval_df

