# -*- coding: utf-8 -*-
import glob
import os
import re
import sys

from source.experiments.experiment_pipline import AFDB_Pipline, DenseNetPipline, DenseNetMultiModelPipline

sys.path.append(os.path.dirname(os.path.abspath(__file__)))


class DenseNetAFDB(AFDB_Pipline, DenseNetPipline):
    # don't need to implement anything
    pass


class DenseNetAFDB_MultimodelTest(AFDB_Pipline, DenseNetMultiModelPipline):
    # don't need to implement anything
    pass


def main():
    pipline = DenseNetAFDB()
    config = pipline.configure_hyperparams()
    pipline.prepare_data(config)
    datamodule = pipline.configure_datamodule(config)

    # cross validate
    for i in range(config.start_fold, config.k_folds):
        datamodule.set_fold_use(i)
        config, datamodule, model, trainer = pipline.train(config, datamodule)
        config, datamodule, model, trainer = pipline.validate(config, datamodule, model)
        if config.single_fold:
            break

    # validate all folds
    models = glob.glob(os.path.join(config.log_dir, config.model_checkpoint_pattern))
    for m in models:
        fold_id = int(re.findall("fold(\d+)", m)[0])
        datamodule.set_fold_use(fold_id)
        config.model_checkpoint = m
        print(f"validating {m}")
        pipline.validate(config, datamodule)

    # test files
    pipline = DenseNetAFDB_MultimodelTest()
    pipline.validate()


if __name__ == "__main__":
    main()
